using BankingProject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using BankingProject.Models;

namespace BankingProject.Controllers
{
    public class HomeController : Controller
    {
        BankingContext obj = new BankingContext();
        public ActionResult Homepage()
        {
            return View();
        }
        public ActionResult Login()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Login(Customer ob)
        {
            var res = (from t in obj.Customers
                       where t.AccountNo == ob.AccountNo && t.AccessCode == ob.AccessCode
                       select t).Count();
            if (res > 0)
            {
                return RedirectToAction("Homepage");
            }

            else
            {
                ViewData["e"] = "Invalid credentials";
            }
            return View();


        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Customer ob)
        {
            obj.Customers.Add(ob);
            int i = obj.SaveChanges();
            var acc = from a in obj.Customers select a.AccountNo;
            if (i > 0)
            { ViewData["e"] = "Account Created and Your Account Number is : " + acc.ToString(); }
            else
            { ViewData["e"] = "Account Creation Failed"; }

            return View();
        }

        public ActionResult AccountClose()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AccountClose(Customer ob)
        {
            obj.Customers.Remove(ob);
            int i = obj.SaveChanges();
            if (i > 0)
            {
                ViewData["e"] = "Account deleted";
            }
            else
            {
                ViewData["e"] = "Enter correct details";
            }
            return View();
        }

        public ActionResult Credit() { 
        return View();
        }
        [HttpPost]
        public ActionResult Credit(Transaction ob)
        {
            var res = (from t in obj.Customers where t.AccountNo == ob.AccountNo select t).Count();
            if(res>0)
            { obj.Transactions.Add(ob);
                int i = obj.SaveChanges();
                if (i > 0) { ViewData["e"] = "Amount Credited"; }
                else
                {
                    ViewData["e"] = "Transaction Failed";
                }
            }
            else
            {
                ViewData["e"] = "Enter Valid Account Number";
            }
            return View();


        }
        public ActionResult Debit()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Debit(Transaction ob)
        {
            var res = (from t in obj.Customers where t.AccountNo == ob.AccountNo select t).Count();
            if (res > 0)
            {
                obj.Transactions.Add(ob);
            int i = obj.SaveChanges();
            if (i > 0) { ViewData["e"] = "Amount Debited"; }
            else
                {
                ViewData["e"] = "Transaction Failed";
                }
            }
            else
            {
                ViewData["e"] = "Enter Valid Account Number";
            }
            return View();
        }
        public ActionResult History()
        {  return View(); }
        [HttpPost]
        public ActionResult History(string ac)
        {
            int i = int.Parse(ac);

            var res = from t in obj.Transactions where t.AccountNo==i select t;
            //ViewData["e"] = res.ToList();
            return View(res.ToList());

        }






    }
}