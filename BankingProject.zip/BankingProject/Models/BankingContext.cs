﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace BankingProject.Models;

public partial class BankingContext : DbContext
{
    public BankingContext()
    {
    }

    public BankingContext(DbContextOptions<BankingContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<Transaction> Transactions { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=ORACLE;Database=Banking;uid=sa;pwd=Root123$;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.AccountNo).HasName("PK__Customer__349D9DFD0036ECA6");

            entity.Property(e => e.AccessCode)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.AccountType)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.Custname)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("custname");
            entity.Property(e => e.Mobile)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("mobile");
        });

        modelBuilder.Entity<Transaction>(entity =>
        {
            entity.HasKey(e => e.Sno).HasName("PK__Transact__CA1EE04CD5C3A139");

            entity.Property(e => e.Sno).HasColumnName("SNo");

            entity.HasOne(d => d.AccountNoNavigation).WithMany(p => p.Transactions)
                .HasForeignKey(d => d.AccountNo)
                .HasConstraintName("FK__Transacti__Accou__3B75D760");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
