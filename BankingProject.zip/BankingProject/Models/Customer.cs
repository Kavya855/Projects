﻿using System;
using System.Collections.Generic;

namespace BankingProject.Models;

public partial class Customer
{
    public int AccountNo { get; set; }

    public string? Custname { get; set; }

    public string? Mobile { get; set; }

    public string? AccessCode { get; set; }

    public string? AccountType { get; set; }

    public virtual ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
}
