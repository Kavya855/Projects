﻿using System;
using System.Collections.Generic;

namespace BankingProject.Models;

public partial class Transaction
{
    public int Sno { get; set; }

    public int? AccountNo { get; set; }

    public int? Credit { get; set; }

    public int? Debit { get; set; }

    public virtual Customer? AccountNoNavigation { get; set; }
}
